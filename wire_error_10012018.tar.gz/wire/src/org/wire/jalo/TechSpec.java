package org.wire.jalo;

import de.hybris.platform.jalo.product.Product;

public class TechSpec extends Product{

}


