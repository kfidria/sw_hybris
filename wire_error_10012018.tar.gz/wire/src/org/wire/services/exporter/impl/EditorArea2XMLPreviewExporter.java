//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.services.exporter.impl;

import de.hybris.platform.cockpit.constants.GeneratedCockpitConstants.TC;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.services.config.EditorSectionConfiguration;
import de.hybris.platform.cockpit.services.reports.ReportsService;
import de.hybris.platform.cockpit.services.exporter.impl.AbstractEditorAreaExporter;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRXmlDataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import com.opentext.otdp.hybris.platform.utils.XmlTools;
import com.opentext.otdp.hybris.platform.streamserve.ex.StreamServeConnectionException;
import com.opentext.otdp.hybris.platform.streamserve.impl.StreamServeHttpInputConnectorService;

import org.zkoss.util.resource.Labels;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import org.wire.config.WireConfig;

public class EditorArea2XMLPreviewExporter extends AbstractEditorAreaExporter {
    private static final Logger LOG = Logger.getLogger(EditorArea2XMLPreviewExporter.class);
    private ReportsService reportsService;
    private Converter<ProductModel, ProductData> productConverter;
    private StreamServeHttpInputConnectorService streamServeHttpInputConnectorService;

    public EditorArea2XMLPreviewExporter() {
    }

	/**
	 * @param productConverter
	 *           the productConverter to set
	 */
	@Required
	public void setProductConverter(final Converter<ProductModel, ProductData> productConverter)
	{
		this.productConverter = productConverter;
	}




	/**
	 * @param streamServeHttpInputConnectorService
	 *           the streamServeHttpInputConnectorService to set
	 */
	@Required
	public void setStreamServeHttpInputConnectorService(
			final StreamServeHttpInputConnectorService streamServeHttpInputConnectorService)
	{
		this.streamServeHttpInputConnectorService = streamServeHttpInputConnectorService;
	}

    public byte[] export(List<EditorSectionConfiguration> ediorsSections, TypedObject curObj) {
       
        byte[] xml = this.generateXml(ediorsSections, curObj);
	String xmlEditString = new String(xml);
	String repl = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
		xmlEditString = xmlEditString.replace(repl, "");
        if (LOG.isDebugEnabled()) {
            LOG.debug(new String(xml));
        }
	

	ProductModel productModel = (ProductModel) curObj.getObject();

	final String orderCode = productModel.getCode();
	final String objectType = "ProductPreview";
	final String documentService = "wireProductServiceImpl";
	final ProductData productData = productConverter.convert(productModel);
	String xmlData = XmlTools.toXmlin(productData);

	StringBuilder buffer = new StringBuilder();
	buffer.append("<opentextData>");
	buffer.append("<previewIP>"+WireConfig.getDefaultPreviewIP()+"</previewIP>");
        buffer.append(xmlData);
	
        buffer.append(xmlEditString);
	buffer.append("</opentextData>");
	if (LOG.isDebugEnabled()){
		LOG.debug("Create order confirmation document for order " + orderCode);
	}
	 	
        try
	{
	
		streamServeHttpInputConnectorService.createDocumentFromXml(buffer.toString(), objectType, orderCode, documentService);
	}catch (final StreamServeConnectionException exc)
	{
		final String msg = "Could not create product document for order " + orderCode;
		LOG.error(msg, exc);
	}
        
        return  String.valueOf(buffer).getBytes();
//	return null;
    }

    public ReportsService getReportsService() {
        return this.reportsService;
    }

    @Required
    public void setReportsService(ReportsService reportsService) {
        this.reportsService = reportsService;
    }

    public String getExportContentType() {
        return "application/xml";
    }
}

