//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.services;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import java.util.List;

public interface WireProductService {
    boolean isBaseProduct(TypedObject var1);

    boolean hasVariants(TypedObject var1);

    List<TypedObject> getVariants(TypedObject var1);

    String getVariantTypecode(TypedObject var1);

    String getApprovalStatusCode(TypedObject var1);

    void setApprovalStatus(TypedObject var1, String var2);

    String getApprovalStatusName(String var1);

    List<String> getAllApprovalStatusCodes();

    List<TypedObject> getPdfDatasheetDocuments(TypedObject var1);

    boolean createPdfDatasheetDocument(ProductModel var1);

    void deletePdfDatasheetDocument(TypedObject var1);
}

