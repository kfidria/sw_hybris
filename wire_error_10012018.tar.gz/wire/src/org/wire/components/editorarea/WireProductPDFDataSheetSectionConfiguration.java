//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.components.editorarea;

import de.hybris.platform.cockpit.components.notifier.Notification;
import de.hybris.platform.cockpit.components.sectionpanel.Section;
import de.hybris.platform.cockpit.components.sectionpanel.SectionPanel;
import de.hybris.platform.cockpit.components.sectionpanel.SectionRenderer;
import de.hybris.platform.cockpit.model.meta.ObjectType;
import de.hybris.platform.cockpit.model.meta.PropertyDescriptor;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.services.config.CustomEditorSectionConfiguration;
import de.hybris.platform.cockpit.services.config.EditorConfiguration;
import de.hybris.platform.cockpit.services.config.EditorSectionConfiguration;
import de.hybris.platform.cockpit.services.config.impl.DefaultEditorSectionConfiguration;
import de.hybris.platform.cockpit.services.meta.TypeService;
import de.hybris.platform.cockpit.services.values.ObjectValueContainer;
import de.hybris.platform.cockpit.session.UISessionUtils;
import de.hybris.platform.cockpit.util.TypeTools;
import org.wire.services.WireProductService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.zkoss.spring.SpringUtil;
import org.zkoss.util.resource.Labels;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Button;
import org.zkoss.zul.Div;
import org.zkoss.zul.Image;
import org.zkoss.zul.Label;
import org.zkoss.zul.Menuitem;
import org.zkoss.zul.Menupopup;
import org.zkoss.zul.Toolbarbutton;

public class WireProductPDFDataSheetSectionConfiguration extends DefaultEditorSectionConfiguration implements CustomEditorSectionConfiguration {
    private static final String PDF_ICON_IMAGE = "/productcockpit/images/docs_PDF.gif";
    TypedObject object;
    ObjectValueContainer objectValues;
    private WireProductService productCockpitProductService = null;
    private TypeService typeService = null;

    public WireProductPDFDataSheetSectionConfiguration() {
    }

    public WireProductService getProductCockpitProductService() {
        if (this.productCockpitProductService == null) {
            this.productCockpitProductService = (WireProductService)SpringUtil.getBean("productCockpitProductService");
        }

        return this.productCockpitProductService;
    }

    public TypeService getTypeService() {
        if (this.typeService == null) {
            this.typeService = (TypeService)SpringUtil.getBean("cockpitTypeService");
        }

        return this.typeService;
    }

    public void allInitialized(EditorConfiguration config, ObjectType type, TypedObject object) {
    }

    public List<EditorSectionConfiguration> getAdditionalSections() {
        return Collections.EMPTY_LIST;
    }

    public SectionRenderer getCustomRenderer() {
        return new SectionRenderer() {
            public void render(final SectionPanel panel, final Component parent, final Component captionComponent, final Section section) {
                Div mainDiv = new Div();
                mainDiv.setStyle("padding: 6px; text-align: left;");
                parent.appendChild(mainDiv);
                Button button = new Button(Labels.getLabel("editorarea.documentsection.create"));
                button.setSclass("btngreen");
                button.addEventListener("onClick", new EventListener() {
                    public void onEvent(Event event) throws Exception {
                        boolean success = WireProductPDFDataSheetSectionConfiguration.this.getProductCockpitProductService().createPdfDatasheetDocument(WireProductPDFDataSheetSectionConfiguration.this.object);
                        if (success) {
                            parent.getChildren().clear();
                            render(panel, parent, captionComponent, section);
                        } else {
                            UISessionUtils.getCurrentSession().getCurrentPerspective().getNotifier().setNotification(new Notification(Labels.getLabel("editorarea.documentsection.pdfcreationerror")));
                        }

                    }
                });
                mainDiv.appendChild(button);
                Div collDiv = new Div();
                collDiv.setStyle("max-height: 150px; overflow-y: auto; overflow-x: hidden; margin-top: 6px;");
                mainDiv.appendChild(collDiv);
                PropertyDescriptor codePD = WireProductPDFDataSheetSectionConfiguration.this.getTypeService().getPropertyDescriptor("Document.code");
                PropertyDescriptor urlPD = WireProductPDFDataSheetSectionConfiguration.this.getTypeService().getPropertyDescriptor("Document.downloadurl");
                Set<PropertyDescriptor> pds = new HashSet();
                pds.add(codePD);
                pds.add(urlPD);
                List<TypedObject> pdfDatasheetDocuments = WireProductPDFDataSheetSectionConfiguration.this.getProductCockpitProductService().getPdfDatasheetDocuments(WireProductPDFDataSheetSectionConfiguration.this.object);
                Iterator var13 = pdfDatasheetDocuments.iterator();

                while(var13.hasNext()) {
                    final TypedObject typedObject = (TypedObject)var13.next();
                    ObjectValueContainer valueContainer = TypeTools.createValueContainer(typedObject, pds, UISessionUtils.getCurrentSession().getSystemService().getAvailableLanguageIsos());
                    String label = (String)valueContainer.getValue(codePD, (String)null).getCurrentValue();
                    final String href = (String)valueContainer.getValue(urlPD, (String)null).getCurrentValue();
                    Div linkDiv = new Div();
                    linkDiv.setStyle("padding: 2px; margin: 2px; border-bottom: 1px dotted #CCCCCC; cursor: pointer; position: relative; white-space: nowrap;");
                    Label l = new Label();
                    Image iconImg = new Image("/productcockpit/images/docs_PDF.gif");
                    linkDiv.appendChild(iconImg);
                    l.setValue(label);
                    linkDiv.appendChild(l);
                    linkDiv.addEventListener("onClick", new EventListener() {
                        public void onEvent(Event event) throws Exception {
                            Clients.evalJavaScript("window.open(\"" + href + "\", \"PDF\", height=600, width=800);");
                        }
                    });
                    Toolbarbutton removeBtn = new Toolbarbutton();
                    removeBtn.setStyle("position: absolute; top: 1px; right: 0; background: white;");
                    removeBtn.setImage("/cockpit/images/remove.png");
                    removeBtn.addEventListener("onClick", new EventListener() {
                        public void onEvent(Event event) throws Exception {
                            WireProductPDFDataSheetSectionConfiguration.this.getProductCockpitProductService().deletePdfDatasheetDocument(typedObject);
                            parent.getChildren().clear();
                            render(panel, parent, captionComponent, section);
                        }
                    });
                    linkDiv.appendChild(removeBtn);
                    Menupopup menu = this.createMenu(typedObject, panel, parent, captionComponent, section);
                    linkDiv.appendChild(menu);
                    linkDiv.setContext(menu);
                    collDiv.appendChild(linkDiv);
                }

            }

            protected Menupopup createMenu(final TypedObject document, final SectionPanel panel, final Component parent, final Component captionComponent, final Section section) {
                Menupopup popup = new Menupopup();
                Menuitem delItem = new Menuitem(Labels.getLabel("general.delete"));
                delItem.addEventListener("onClick", new EventListener() {
                    public void onEvent(Event event) throws Exception {
                        WireProductPDFDataSheetSectionConfiguration.this.getProductCockpitProductService().deletePdfDatasheetDocument(document);
                        parent.getChildren().clear();
                        render(panel, parent, captionComponent, section);
                    }
                });
                popup.appendChild(delItem);
                Menuitem delAllItem = new Menuitem(Labels.getLabel("general.deleteall"));
                delAllItem.addEventListener("onClick", new EventListener() {
                    public void onEvent(Event event) throws Exception {
                        List<TypedObject> pdfDatasheetDocuments = new ArrayList(WireProductPDFDataSheetSectionConfiguration.this.getProductCockpitProductService().getPdfDatasheetDocuments(WireProductPDFDataSheetSectionConfiguration.this.object));
                        Iterator var4 = pdfDatasheetDocuments.iterator();

                        while(var4.hasNext()) {
                            TypedObject typedObject = (TypedObject)var4.next();
                            WireProductPDFDataSheetSectionConfiguration.this.getProductCockpitProductService().deletePdfDatasheetDocument(typedObject);
                        }

                        parent.getChildren().clear();
                        render(panel, parent, captionComponent, section);
                    }
                });
                popup.appendChild(delAllItem);
                return popup;
            }
        };
    }

    public void initialize(EditorConfiguration config, ObjectType type, TypedObject object) {
    }

    public void loadValues(EditorConfiguration config, ObjectType type, TypedObject object, ObjectValueContainer objectValues) {
        this.object = object;
        this.objectValues = objectValues;
    }

    public void saveValues(EditorConfiguration config, ObjectType type, TypedObject object, ObjectValueContainer objectValues) {
    }
}

