//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.components.editorarea.export;

import de.hybris.platform.cockpit.components.listview.AbstractListViewAction;
import de.hybris.platform.cockpit.components.listview.ListViewAction.Context;
import de.hybris.platform.cockpit.model.editor.EditorHelper;
import de.hybris.platform.cockpit.model.meta.ObjectTemplate;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.services.config.EditorConfiguration;
import de.hybris.platform.cockpit.services.config.EditorSectionConfiguration;
import de.hybris.platform.cockpit.services.config.UIConfigurationService;
import de.hybris.platform.cockpit.services.exporter.EditorAreaExporter;
import de.hybris.platform.cockpit.services.meta.TypeService;
import de.hybris.platform.cockpit.session.UISessionUtils;
import de.hybris.platform.cockpit.util.TypeTools;
import java.util.List;
import org.springframework.beans.factory.annotation.Required;
import org.zkoss.util.resource.Labels;
import org.zkoss.zhtml.Filedownload;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Menupopup;

public class DefaultExportEditorAreaAction extends AbstractListViewAction {
    private UIConfigurationService uIConfigurationService;
    private TypeService typeService;
    private EditorAreaExporter editorAreaExporter;
    private String fileName;
    private String imageURI = "/cockpit/images/icon_func_get_pdf_available.png";
    private String tooltip = "editorarea.pdf.preview.tooltip";

    public DefaultExportEditorAreaAction() {
    }

    protected void doCreateContext(Context context) {
    }

    public Menupopup getContextPopup(Context context) {
        return null;
    }

    public EventListener getEventListener(final Context context) {
        return new EventListener() {
            public void onEvent(Event event) throws Exception {
                if ("onClickLater".equals(event.getName())) {
                    Clients.showBusy((String)null, true);
                    Component img = event.getTarget();
                    img.addEventListener("onExport", this);
                    Events.echoEvent("onExport", img, (String)null);
                } else if ("onClick".equals(event.getName())) {
                    this.export();
                } else if ("onExport".equals(event.getName())) {
                    this.export();
                    Clients.showBusy((String)null, false);
                }

            }

            private void export() {
                TypedObject curObj = context.getItem();
                if (curObj == null) {
                    curObj = UISessionUtils.getCurrentSession().getCurrentPerspective().getEditorArea().getCurrentObject();
                }

                curObj = DefaultExportEditorAreaAction.this.getTypeService().wrapItem(curObj.getObject());
                EditorConfiguration editorConf = UISessionUtils.getCurrentSession().getCurrentPerspective().getEditorArea().getEditorAreaController().getModel().getTypeConfiguration();
                List<EditorSectionConfiguration> editorsSections = null;
                if (editorConf == null) {
                    editorConf = DefaultExportEditorAreaAction.this.getConfiguration(curObj.getType().getCode());
                    EditorHelper.initializeSections(editorConf, curObj.getType(), curObj, DefaultExportEditorAreaAction.this.getTypeService());
                }

                editorsSections = editorConf.getSections();
                byte[] pdf = DefaultExportEditorAreaAction.this.getEditorAreaExporter().export(editorsSections, curObj);
                

            }
        };
    }

    protected String getFileName(TypedObject item) {
        return this.getFileName() == null ? TypeTools.getValueAsString(UISessionUtils.getCurrentSession().getLabelService(), item) : this.getFileName();
    }

    public String getImageURI(Context context) {
        return this.imageURI;
    }

    public void setImageURI(String imageURI) {
        this.imageURI = imageURI;
    }

    public Menupopup getPopup(Context context) {
        return null;
    }

    public String getTooltip(Context context) {
        return Labels.getLabel(this.tooltip);
    }

    public void setEditorAreaExporter(EditorAreaExporter editorAreaExporter) {
        this.editorAreaExporter = editorAreaExporter;
    }

    public EditorConfiguration getConfiguration(String typecode) {
        ObjectTemplate template = UISessionUtils.getCurrentSession().getTypeService().getObjectTemplate(typecode);
        return (EditorConfiguration)this.uIConfigurationService.getComponentConfiguration(template, "editorArea", EditorConfiguration.class);
    }

    @Required
    public void setuIConfigurationService(UIConfigurationService uIConfigurationService) {
        this.uIConfigurationService = uIConfigurationService;
    }

    protected EditorAreaExporter getEditorAreaExporter() {
        return this.editorAreaExporter;
    }

    protected String getFileName() {
        return this.fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }

    private TypeService getTypeService() {
        if (this.typeService == null) {
            this.typeService = UISessionUtils.getCurrentSession().getTypeService();
        }

        return this.typeService;
    }
}

