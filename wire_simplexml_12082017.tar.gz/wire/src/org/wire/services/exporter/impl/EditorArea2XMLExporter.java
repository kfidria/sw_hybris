//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.cockpit.services.exporter.impl;

import de.hybris.platform.cockpit.constants.GeneratedCockpitConstants.TC;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.services.config.EditorSectionConfiguration;
import de.hybris.platform.cockpit.services.reports.ReportsService;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRXmlDataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.zkoss.util.resource.Labels;
import  de.hybris.platform.cockpit.services.exporter.impl.AbstractEditorAreaExporter;


public class EditorArea2XMLExporter extends AbstractEditorAreaExporter {
    private static final Logger LOG = Logger.getLogger(EditorArea2XMLExporter.class);
    private ReportsService reportsService;

    public EditorArea2XMLExporter() {
    }

    public byte[] export(List<EditorSectionConfiguration> ediorsSections, TypedObject curObj) {
        byte[] pdf = new byte[0];
        byte[] xml = this.generateXml(ediorsSections, curObj);
        if (LOG.isDebugEnabled()) {
            LOG.debug(new String(xml));
        }

        ByteArrayInputStream data = new ByteArrayInputStream(xml);

        try {
            JasperReport mainReport = this.getReportsService().getMainReport(this.getPreferencesTitle());
            Map<String, Object> params = this.getReportsService().getMainReportParameters(this.getPreferencesTitle());
            String mainTitle = (String)params.get("MAIN_REPORT_TITLE");
            params.put("MAIN_REPORT_TITLE", Labels.getLabel(mainTitle));
            String mainReportDSExp = (String)params.get(this.getDataSourceExpParamName());
            JasperPrint mainPrint = JasperFillManager.fillReport(mainReport, params, new JRXmlDataSource(data, mainReportDSExp));
            pdf = JasperExportManager.exportReportToPdf(mainPrint);
        } catch (JRException var11) {
            LOG.error("Exception occurred while filling/exporting report for " + TC.WIDGETPREFERENCES + " object with title: " + this.getPreferencesTitle(), var11);
        }

        return xml;
    }

    public ReportsService getReportsService() {
        return this.reportsService;
    }

    @Required
    public void setReportsService(ReportsService reportsService) {
        this.reportsService = reportsService;
    }

    public String getExportContentType() {
        return "application/xml";
    }
}

