/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Dec 8, 2017 10:18:06 AM                     ---
 * ----------------------------------------------------------------
 */
package org.wire.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedWireConstants
{
	public static final String EXTENSIONNAME = "wire";
	
	protected GeneratedWireConstants()
	{
		// private constructor
	}
	
	
}
