//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.services.impl;

import bsh.EvalError;

import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commerceservices.impersonation.ImpersonationContext;
import de.hybris.platform.commerceservices.impersonation.ImpersonationService;
import de.hybris.platform.catalog.jalo.CatalogManager;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cockpit.model.meta.PropertyDescriptor;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.services.values.ObjectValueContainer;
import de.hybris.platform.cockpit.session.UISessionUtils;
import de.hybris.platform.cockpit.services.meta.TypeService;
import de.hybris.platform.cockpit.util.TypeTools;
import de.hybris.platform.cockpit.util.ValueContainerMap;
import de.hybris.platform.cockpit.util.ValueContainerMap.PropertyFilter;
import de.hybris.platform.commons.jalo.CommonsManager;
import de.hybris.platform.commons.jalo.Document;
import de.hybris.platform.commons.model.DocumentModel;
import de.hybris.platform.core.HybrisEnumValue;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.product.ProductModel;
import org.wire.model.TechSpecModel;
import de.hybris.platform.jalo.ConsistencyCheckException;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.enumeration.EnumerationManager;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.product.VariantsService;
import de.hybris.platform.servicelayer.media.MediaService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;
import de.hybris.platform.site.BaseSiteService;
import de.hybris.platform.variants.model.VariantProductModel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import com.opentext.otdp.hybris.platform.streamserve.StreamServeDocumentService;

import org.wire.config.WireConfig;

public class WireProductServiceImpl implements StreamServeDocumentService {

    private BaseSiteService baseSiteService;
    private ImpersonationService impersonationService;
    private static final Logger log = Logger.getLogger(WireProductServiceImpl.class);
    private TypeService typeService;
    private ModelService modelService;
    private FlexibleSearchService flexibleSearchService;
    private MediaService mediaService;
    private CatalogVersionService catalogVersionService;

    @Required
    public void setBaseSiteService(final BaseSiteService baseSiteService)
    {
        this.baseSiteService = baseSiteService;
    }

    @Required
    public void setFlexibleSearchService(final FlexibleSearchService flexibleSearchService)
    {
        this.flexibleSearchService = flexibleSearchService;
    }

    public ModelService getModelService() {
        return this.modelService;
    }

    public void setModelService(ModelService modelService) {
        this.modelService = modelService;
    }

    @Required
    public void setMediaService(final MediaService mediaService)
    {
        this.mediaService = mediaService;
    }

    public TypeService getTypeService() {
        return this.typeService;
    }

    public void setTypeService(TypeService typeService) {
        this.typeService = typeService;
    }

    @Required
    public void setCatalogVersionService(final CatalogVersionService catalogVersionService)
    {
        this.catalogVersionService = catalogVersionService;
    }

    @Required
    public void setImpersonationService(final ImpersonationService impersonationService)
    {
        this.impersonationService = impersonationService;
    }

    public WireProductServiceImpl() {
    }

    @Override
    public void handleReceivedDocument(final byte[] documentContent,
                                       final String mimeType,
                                       final String documentDefinitionId,
                                       final String documentDefinitionName,
                                       final String objectType,
                                       final String objectKey) throws Exception
    {
        if (log.isTraceEnabled())
        {
            log.trace("Handle document content with mimetype "
                    + mimeType
                    + " for object type "
                    + objectType
                    + " with key "
                    + objectKey);
        }
        attachDocument2Order(documentContent, mimeType, documentDefinitionName, objectKey);
    }

    protected void attachDocument2Order(final byte[] documentContent,
                                        final String mimeType,
                                        final String documentDefinitionName,
                                        final String orderKey) throws Exception
    {
        String timeMillis = String.valueOf(System.currentTimeMillis());
        // build document code based on document definition, order key and timestamp
        String documentCode = documentDefinitionName + "/" + orderKey + "/" + timeMillis;
        final CMSSiteModel baseSite = (CMSSiteModel) baseSiteService.getAllBaseSites().iterator().next();
        ImpersonationContext context = new ImpersonationContext();
	List<CatalogVersionModel> ar= new ArrayList<>();
	ar.add(catalogVersionService.getCatalogVersion("powertoolsProductCatalog", "Online"));
        context.setCatalogVersions(ar);
        context.setSite(baseSite);

        TechSpecModel productModel = (TechSpecModel) impersonationService.executeInContext(context,
                new ImpersonationService.Executor<Object, ImpersonationService.Nothing>()
                {
                    @Override
                    public Object execute(){

                        FlexibleSearchQuery query =
                                new FlexibleSearchQuery("SELECT {pk} FROM {TechSpec} WHERE {code} =?code");

                        query.addQueryParameter("code", orderKey);
                        SearchResult<TechSpecModel> searchResult = flexibleSearchService.search(query);
                        List<TechSpecModel> result = searchResult.getResult();
 			if (log.isInfoEnabled())
		        {
                		log.info("Product Model: " + result.get(0));
		        }	
                        return result.get(0);
                    }
                });

        if ( productModel != null)
        {
            // create document of type Media
            final CatalogVersionModel catalogVersionModel =
                    catalogVersionService.getCatalogVersion("powertoolsProductCatalog", "Online");

            final MediaModel opentextDocument = modelService.create(MediaModel.class);
            opentextDocument.setCode(documentCode);
            opentextDocument.setCatalogVersion(catalogVersionModel);
            opentextDocument.setMime(mimeType);
            opentextDocument.setLocation(WireConfig.getDefaultDocumentMediaLocation()
                    + "/"
                    + orderKey
                    + "_"
                    + timeMillis
                    + ".pdf");
            opentextDocument.setFolder(mediaService.getFolder(WireConfig.getDefaultDocumentMediaFolder()));

            modelService.save(opentextDocument);

            // store content in document
            mediaService.setDataForMedia(opentextDocument, documentContent);
            if (log.isInfoEnabled())
            {
                log.info("Attached document with code: "
                        + documentCode
                        + ", with size "
                        + documentContent.length
                        + " bytes");
            }

            // attach document collection to order
	    List<MediaModel> documents = new ArrayList();
	    if (productModel.getData_sheet() != null)
	    {
            	documents = new ArrayList(productModel.getData_sheet());
	    }
       	    documents.add(opentextDocument);
            productModel.setData_sheet(documents);

            // save order
            modelService.save(productModel);
        }
        else
        {
            log.info("Unable to find Produc: " + orderKey);
        }
    }

}

