//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.components.listview.impl;

import de.hybris.platform.cockpit.components.contentbrowser.MultiTypeListMainAreaComponentFactory.MultiTypeListViewConfiguration;
import de.hybris.platform.cockpit.components.listview.AbstractMultiSelectOnlyAction;
import de.hybris.platform.cockpit.components.listview.ListViewAction.Context;
import de.hybris.platform.cockpit.model.listview.ColumnDescriptor;
import de.hybris.platform.cockpit.model.listview.ColumnModel;
import de.hybris.platform.cockpit.model.listview.TableModel;
import de.hybris.platform.cockpit.model.listview.impl.DefaultColumnModel;
import de.hybris.platform.cockpit.model.meta.PropertyDescriptor;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.services.config.ColumnConfiguration;
import de.hybris.platform.cockpit.services.config.impl.MultiTypeColumnConfiguration;
import de.hybris.platform.cockpit.services.label.LabelService;
import de.hybris.platform.cockpit.services.values.ObjectValueContainer;
import de.hybris.platform.cockpit.services.values.ValueHandlerException;
import de.hybris.platform.cockpit.services.values.ObjectValueContainer.ObjectValueHolder;
import de.hybris.platform.cockpit.session.BrowserModel;
import de.hybris.platform.cockpit.session.UISessionUtils;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.cockpit.util.TypeTools;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.zkoss.util.resource.Labels;
import org.zkoss.zhtml.Filedownload;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zul.Menupopup;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import com.opentext.otdp.hybris.platform.utils.XmlTools;
import com.opentext.otdp.hybris.platform.streamserve.ex.StreamServeConnectionException;
import com.opentext.otdp.hybris.platform.streamserve.impl.StreamServeHttpInputConnectorService;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

public class ExportXMLAction extends AbstractMultiSelectOnlyAction {
	
    private static final Logger LOG = Logger.getLogger(ExportXMLAction.class);
    protected static final String ICON_EXPORT_XML_ACTION_AVAILABLE = "cockpit/images/icon_pdf.png";
    protected static final String ICON_EXPORT_XML_ACTION_UNAVAILABLE = "cockpit/images/icon_pdf_unavailable.png";
    private Converter<ProductModel, ProductData> productConverter;
    private boolean truncateCollections;
    private LabelService labelService;
    private StreamServeHttpInputConnectorService streamServeHttpInputConnectorService;
	
/**
    * @param productConverter
    *           the productConverter to set
    */
    @Required
    public void setProductConverter(final Converter<ProductModel, ProductData> productConverter)
    {
	this.productConverter = productConverter;
    }

    public ExportXMLAction() {
    }

    public EventListener getMultiSelectEventListener(final Context context) {
        EventListener ret = null;
        final List<TypedObject> selectedItems = this.getSelectedItems(context);
        if (context.getModel() != null && selectedItems != null && !selectedItems.isEmpty() && selectedItems.size() >= 1) {
            ret = new EventListener() {
                public void onEvent(Event event) throws Exception {
                    TableModel tableModel = context.getModel();
                    if (tableModel != null) {
                        ColumnModel columnComponentModel = tableModel.getColumnComponentModel();
	
                        if (columnComponentModel instanceof DefaultColumnModel && ((DefaultColumnModel)columnComponentModel).getConfiguration() instanceof MultiTypeListViewConfiguration) {
                            ExportXMLAction.this.createAndSaveCSVForMultitype((MultiTypeListViewConfiguration)((DefaultColumnModel)columnComponentModel).getConfiguration(), selectedItems);
                        } else {
			    
                            ExportXMLAction.this.createAndSavePDF(context);
                        }
                    }

                }
            };
        }

        return ret;
    }

	
		/**
	 * @param streamServeHttpInputConnectorService
	 *           the streamServeHttpInputConnectorService to set
	 */	
	@Required
	public void setStreamServeHttpInputConnectorService(
			final StreamServeHttpInputConnectorService streamServeHttpInputConnectorService)
	{
		this.streamServeHttpInputConnectorService = streamServeHttpInputConnectorService;
	}

    public String getMultiSelectImageURI(Context context) {
        List<TypedObject> selectedItems = this.getSelectedItems(context);
        return context.getModel() != null && selectedItems != null && !selectedItems.isEmpty() && selectedItems.size() >= 1 ? "cockpit/images/icon_pdf.png" : "cockpit/images/icon_pdf_unavailable.png";
    }

    public Menupopup getMultiSelectPopup(Context context) {
        return null;
    }

    public String getTooltip(Context context) {
		return Labels.getLabel("listview.exportxmlaction.tooltip");
    }

    private void createAndSaveCSVForMultitype(MultiTypeListViewConfiguration multiTypeListViewConfiguration, List<TypedObject> list) throws ValueHandlerException {
        StringBuilder bufferAll = new StringBuilder();
        List<MultiTypeColumnConfiguration> columnConfigurations = new ArrayList();
        Iterator var6 = multiTypeListViewConfiguration.getRootColumnGroupConfiguration().getColumnConfigurations().iterator();

        while(var6.hasNext()) {
            ColumnConfiguration columnConfiguration = (ColumnConfiguration)var6.next();
            if (columnConfiguration instanceof MultiTypeColumnConfiguration && ((MultiTypeColumnConfiguration)columnConfiguration).getColumnDescriptor().isVisible()) {
                columnConfigurations.add((MultiTypeColumnConfiguration)columnConfiguration);
            }
        }

//	StringBuilder headerRow = new StringBuilder();
	List<String> headerNames = new ArrayList();
                
        var6 = columnConfigurations.iterator();
//		headerRow.append("<row>").append('\n');
        while(var6.hasNext()) {
            MultiTypeColumnConfiguration columnConfiguration = (MultiTypeColumnConfiguration)var6.next();
 //           headerRow.append("<cell>").append(columnConfiguration.getColumnDescriptor().getName()).append("</cell>").append('\n');
		headerNames.add(columnConfiguration.getColumnDescriptor().getName());
        }
//		headerRow.append("</row>").append('\n');
        
        var6 = list.iterator();

        while(var6.hasNext()) {
			StringBuilder buffer = new StringBuilder();
			buffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");

			buffer.append("<opentextData>");
            Object item = var6.next();
			ProductModel productModel = (ProductModel) ((TypedObject)item).getObject();
			String orderCode = productModel.getCode();
			ProductData productData = productConverter.convert(productModel);
			String xmlData = XmlTools.toXmlin(productData);
			buffer.append(xmlData);

			buffer.append("<tableData>");
			//buffer.append(headerRow);
            Iterator var8 = columnConfigurations.iterator();
			buffer.append("<row>").append('\n');
		int itemNum =0;
            while(var8.hasNext()) {
                ColumnConfiguration columnConfiguration = (ColumnConfiguration)var8.next();
                String columnValue = this.getEscapedCsvColumnValue(String.valueOf(((MultiTypeColumnConfiguration)columnConfiguration).getValueHandler().getValue((TypedObject)item)));
                buffer.append("<cell name=\"").append(headerNames.get(itemNum)).append("\">").append(columnValue).append("</cell>").append('\n');
		itemNum++;
            }
            buffer.append("</row>").append('\n');

			buffer.append("</tableData>");
			buffer.append("</opentextData>");
			this.triggerStreamServe(buffer.toString(), orderCode);
			bufferAll.append(buffer);
			
        }
		
//		Filedownload.save(bufferAll.toString(), "text/xml;charset=UTF-8", "xml.xml");

    }

    private String getEscapedCsvColumnValue(String value) {
        String ret = value;
        if (value.contains(";") || value.contains("\"")) {
            ret = "\"" + value.replace("\"", "\"\"") + "\"";
        }

        return ret.replace('\n', ' ');
    }

    private void createAndSavePDF(Context context) {
		
        BrowserModel browser = context.getBrowserModel();
        TableModel tableModel = context.getModel();
		if (LOG.isTraceEnabled()){
			LOG.trace("Enable createAndSavePDF");
		}
						
		ProductModel productModel = (ProductModel) context.getItem().getObject();
		final String orderCode = productModel.getCode();
		ProductData productData = productConverter.convert(productModel);
		String xmlData = XmlTools.toXmlin(productData);
		
		
		StringBuilder buffer = new StringBuilder();
		buffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
		buffer.append("<opentextData>");
   		buffer.append(xmlData);
		buffer.append("<tableData>");		
        if (browser != null && tableModel != null) {
            List<TypedObject> allItems = browser.getSelectedItems();
            List<ColumnDescriptor> visibleColumns = tableModel.getColumnComponentModel().getVisibleColumns();
            if (allItems != null) {
                List<ExportXMLAction.LocalizedProperty> localizedPropertyDescriptors = new ArrayList();
                Set<PropertyDescriptor> propertyDescriptors = new HashSet();
		List<String> headerNames = new ArrayList();
                Iterator var10 = visibleColumns.iterator();
	//			buffer.append("<row>");
                while(var10.hasNext()) {
                    ColumnDescriptor columnDescriptor = (ColumnDescriptor)var10.next();
                    ColumnModel columnComponentModel = tableModel.getColumnComponentModel();
                    PropertyDescriptor propertyDescriptor = columnComponentModel.getPropertyDescriptor(columnDescriptor);
                    if (propertyDescriptor != null) {
                        localizedPropertyDescriptors.add(new ExportXMLAction.LocalizedProperty(propertyDescriptor, columnDescriptor.getLanguage() == null ? null : columnDescriptor.getLanguage().getIsocode()));
                        propertyDescriptors.add(propertyDescriptor);
             //           buffer.append("<cell>").append(columnDescriptor.getName()).append("</cell>");
			headerNames.add(columnDescriptor.getName());
	//		buffer.append('\n');
                    }
                }
	//			buffer.append("</row>").append('\n');
                var10 = allItems.iterator();
				                
				while(var10.hasNext()) {
                    TypedObject item = (TypedObject)var10.next();
                    buffer.append("<row>").append(this.getXMLRow(item, localizedPropertyDescriptors, propertyDescriptors, headerNames)).append("</row>").append('\n');
                }
	
				buffer.append("</tableData>");
				
				buffer.append("</opentextData>");
				this.triggerStreamServe(buffer.toString(), orderCode);
            //    Filedownload.save(buffer.toString(), "text/xml;charset=UTF-8", "store.xml");
            }
        }

    }

    private String getXMLRow(TypedObject item, List<ExportXMLAction.LocalizedProperty> localizedPropertyDescriptors, Set<PropertyDescriptor> descriptors, List<String> headerNames) {
        StringBuffer buffer = new StringBuffer();
        ObjectValueContainer valueContainer = TypeTools.createValueContainer(item, descriptors, UISessionUtils.getCurrentSession().getSystemService().getAvailableLanguageIsos());
	int itemNum = 0;
        for(Iterator var7 = localizedPropertyDescriptors.iterator(); var7.hasNext(); buffer.append('\n')) {
            ExportXMLAction.LocalizedProperty localizedProperty = (ExportXMLAction.LocalizedProperty)var7.next();
            Object value = null;
            if (valueContainer.hasProperty(localizedProperty.getPropDesc(), localizedProperty.getLang())) {
                ObjectValueHolder valueHolder = valueContainer.getValue(localizedProperty.getPropDesc(), localizedProperty.getLang());
                value = valueHolder.getCurrentValue();
            }

            if (value != null) {
                String valueAsString = "";
                if (this.truncateCollections) {
                    valueAsString = TypeTools.getValueAsString(this.labelService, value);
                } else {
                    valueAsString = TypeTools.getValueAsString(this.labelService, value, -1);
                }

                if (valueAsString == null) {
                    valueAsString = "";
                } 
		//else {
                //    valueAsString = this.getEscapedCsvColumnValue(valueAsString);
                //}

                buffer.append("<cell name=\"").append(headerNames.get(itemNum)).append("\"><![CDATA[").append(valueAsString).append("]]></cell>");
            }
		itemNum++;
        }

        buffer.append('\n');

        return buffer.toString();
    }

	protected void triggerStreamServe(String buffer, String orderCode){
		
		final String objectType = "Product";
		final String documentService = "wireProductServiceImpl";
		try
		{	
			streamServeHttpInputConnectorService.createDocumentFromXml(buffer, objectType, orderCode, documentService);
		}catch (final StreamServeConnectionException exc)
		{
			final String msg = "Could not create product document for order " + orderCode;
			LOG.error(msg, exc);
		}
	}
	
    public void setLabelService(LabelService labelService) {
        this.labelService = labelService;
    }

    public LabelService getLabelService() {
        if (this.labelService == null) {
            this.labelService = UISessionUtils.getCurrentSession().getLabelService();
        }

        return this.labelService;
    }

    public boolean isTruncateCollections() {
        return this.truncateCollections;
    }

    public void setTruncateCollections(boolean truncateCollections) {
        this.truncateCollections = truncateCollections;
    }

    private class LocalizedProperty {
        private final PropertyDescriptor propDesc;
        private final String lang;

        public LocalizedProperty(PropertyDescriptor propDesc, String lang) {
            this.propDesc = propDesc;
            this.lang = lang;
        }

        public PropertyDescriptor getPropDesc() {
            return this.propDesc;
        }

        public String getLang() {
            return this.lang;
        }
    }
}

