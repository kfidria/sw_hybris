//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.wire.components.editorarea.export;

import de.hybris.platform.cockpit.components.listview.ListViewAction.Context;
import  org.wire.components.editorarea.export.DefaultExportEditorAreaAction;
import de.hybris.platform.cockpit.model.meta.TypedObject;
import de.hybris.platform.cockpit.session.UISessionUtils;
import de.hybris.platform.cockpit.util.TypeTools;
import de.hybris.platform.core.model.product.ProductModel;
import java.util.List;
import org.zkoss.zk.ui.event.EventListener;

public class ExportEditorArea2XMLAction extends DefaultExportEditorAreaAction {
   

    public ExportEditorArea2XMLAction() {
    }

    public String getFileName(TypedObject item) {
        if (this.getFileName() == null) {
            Object obj = item.getObject();
            return obj instanceof ProductModel ? ((ProductModel)obj).getCode() + ".xml" : TypeTools.getValueAsString(UISessionUtils.getCurrentSession().getLabelService(), item);
        } else {
            return this.getFileName();
        }
    }

  
}

