package org.wire.model;

import de.hybris.platform.core.model.product.ProductModel;

public class TechSpecModel extends ProductModel{

}


