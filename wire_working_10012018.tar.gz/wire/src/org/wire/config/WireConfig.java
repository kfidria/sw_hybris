/*
* Copyright (c) 2007-2015 by Open Text Corporation. All Rights Reserved.
*
* This software is the confidential and proprietary information of Open
* Text Corporation ("Confidential Information"). You shall not disclose
* such Confidential Information and shall use it only in accordance with
* the terms of the license agreement you entered into with Open Text.
*
* OPEN TEXT MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
* OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
* TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. OPEN TEXT SHALL NOT BE LIABLE FOR ANY
* DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
* DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*
* $Id: //products/comp/otdp.hybris.order/16.0.0-branch/pkg/OTDP_HYBRIS_ORDER/opentextdpb2baccelerator/src/com/opentext/otdp/hybris/b2b/config/Opentextdpb2bacceleratorConfig.java#1 $
* $Revision: #1 $
* $DateTime: 2016/10/17 19:31:28 $
* $Change: 8202790 $
*/
package org.wire.config;


import de.hybris.platform.core.Registry;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;


/**
 * This class provides access to extension specific properties defined in project.properties that might be changed by
 * customers in local.properties or the hybris Admin Console Platform Configuration. These property values need to be
 * retrieved dynamically and not defined as static constants, because the configuration can be changed dynamically in
 * the hybris Admin Console!
 */
public class WireConfig
{

	// Logger used in this class
	private static final Logger LOG = Logger.getLogger(WireConfig.class);

	// Configuration property names used in project.properties
	public static final String PROPERTY_NAME_DEFAULT_CATALOG = "opentextdpb2baccelerator.default_catalog";
	public static final String PROPERTY_NAME_DEFAULT_CATALOG_VERSION = "opentextdpb2baccelerator.default_catalog_version";
	public static final String PROPERTY_NAME_DEFAULT_DOCUMENT_MEDIA_LOCATION = "opentextdpb2baccelerator.default_media_location";
	public static final String PROPERTY_NAME_DEFAULT_DOCUMENT_MEDIA_FOLDER = "opentextdpb2baccelerator.default_media_folder";
	public static final String PROPERTY_NAME_DEFAULT_PREVIEW_IP=
"10.10.108.42";	


	private static ConfigurationService mConfSvc = null;

	// static initialization of the configuration service bean
	static
	{
		try
		{
			mConfSvc = (ConfigurationService) Registry.getApplicationContext().getBean("configurationService");
		}
		catch (final BeansException ex)
		{
			LOG.error(
					"Configuration properties for opentextdpb2baccelerator extension are not available, because the configurationService bean could not be retrieved from the application context registry.");
		}
	}

	/** Return default catalog used for storing OpenText documents */
	public static String getDefaultCatalog()
	{
		if (mConfSvc != null)
		{
			return mConfSvc.getConfiguration().getString(PROPERTY_NAME_DEFAULT_CATALOG);
		}
		else
		{
			return null;
		}
	}

	/** Return default catalog version used for storing OpenText documents */
	public static String getDefaultCatalogVersion()
	{
		if (mConfSvc != null)
		{
			return mConfSvc.getConfiguration().getString(PROPERTY_NAME_DEFAULT_CATALOG_VERSION);
		}
		else
		{
			return null;
		}
	}

	/** Return default preview ip used for storing OpenText documents */
	public static String getDefaultPreviewIP()
	{
		return PROPERTY_NAME_DEFAULT_PREVIEW_IP;
		
	}


	/** Return default media location used for storing OpenText documents */
	public static String getDefaultDocumentMediaLocation()
	{
		if (mConfSvc != null)
		{
			return mConfSvc.getConfiguration().getString(PROPERTY_NAME_DEFAULT_DOCUMENT_MEDIA_LOCATION);
		}
		else
		{
			return null;
		}
	}


	/** Return default media folder used for storing OpenText documents */
	public static String getDefaultDocumentMediaFolder()
	{
		if (mConfSvc != null)
		{
			return mConfSvc.getConfiguration().getString(PROPERTY_NAME_DEFAULT_DOCUMENT_MEDIA_FOLDER);
		}
		else
		{
			return null;
		}
	}

}

