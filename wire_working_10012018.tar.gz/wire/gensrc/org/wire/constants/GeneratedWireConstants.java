/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jan 10, 2018 2:06:12 PM                     ---
 * ----------------------------------------------------------------
 */
package org.wire.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedWireConstants
{
	public static final String EXTENSIONNAME = "wire";
	public static class TC
	{
		public static final String TECHSPEC = "TechSpec".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	
	protected GeneratedWireConstants()
	{
		// private constructor
	}
	
	
}
