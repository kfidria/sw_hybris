/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jan 10, 2018 2:06:12 PM                     ---
 * ----------------------------------------------------------------
 */
package org.wire.jalo;

import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.product.Product;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.wire.constants.WireConstants;

/**
 * Generated class for type {@link org.wire.jalo.TechSpec TechSpec}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedTechSpec extends Product
{
	/** Qualifier of the <code>TechSpec.specTitle</code> attribute **/
	public static final String SPECTITLE = "specTitle";
	/** Qualifier of the <code>TechSpec.specNumber</code> attribute **/
	public static final String SPECNUMBER = "specNumber";
	/** Qualifier of the <code>TechSpec.specDescription</code> attribute **/
	public static final String SPECDESCRIPTION = "specDescription";
	/** Qualifier of the <code>TechSpec.specConstructions</code> attribute **/
	public static final String SPECCONSTRUCTIONS = "specConstructions";
	/** Qualifier of the <code>TechSpec.specFeatures</code> attribute **/
	public static final String SPECFEATURES = "specFeatures";
	/** Qualifier of the <code>TechSpec.specSpecifications</code> attribute **/
	public static final String SPECSPECIFICATIONS = "specSpecifications";
	/** Qualifier of the <code>TechSpec.specLegend</code> attribute **/
	public static final String SPECLEGEND = "specLegend";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Product.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(SPECTITLE, AttributeMode.INITIAL);
		tmp.put(SPECNUMBER, AttributeMode.INITIAL);
		tmp.put(SPECDESCRIPTION, AttributeMode.INITIAL);
		tmp.put(SPECCONSTRUCTIONS, AttributeMode.INITIAL);
		tmp.put(SPECFEATURES, AttributeMode.INITIAL);
		tmp.put(SPECSPECIFICATIONS, AttributeMode.INITIAL);
		tmp.put(SPECLEGEND, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specConstructions</code> attribute.
	 * @return the specConstructions - Technical Specification Features
	 */
	public String getSpecConstructions(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECCONSTRUCTIONS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specConstructions</code> attribute.
	 * @return the specConstructions - Technical Specification Features
	 */
	public String getSpecConstructions()
	{
		return getSpecConstructions( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specConstructions</code> attribute. 
	 * @param value the specConstructions - Technical Specification Features
	 */
	public void setSpecConstructions(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECCONSTRUCTIONS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specConstructions</code> attribute. 
	 * @param value the specConstructions - Technical Specification Features
	 */
	public void setSpecConstructions(final String value)
	{
		setSpecConstructions( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specDescription</code> attribute.
	 * @return the specDescription - Technical Specification Description
	 */
	public String getSpecDescription(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECDESCRIPTION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specDescription</code> attribute.
	 * @return the specDescription - Technical Specification Description
	 */
	public String getSpecDescription()
	{
		return getSpecDescription( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specDescription</code> attribute. 
	 * @param value the specDescription - Technical Specification Description
	 */
	public void setSpecDescription(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECDESCRIPTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specDescription</code> attribute. 
	 * @param value the specDescription - Technical Specification Description
	 */
	public void setSpecDescription(final String value)
	{
		setSpecDescription( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specFeatures</code> attribute.
	 * @return the specFeatures - Technical Specification Constructions List
	 */
	public String getSpecFeatures(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECFEATURES);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specFeatures</code> attribute.
	 * @return the specFeatures - Technical Specification Constructions List
	 */
	public String getSpecFeatures()
	{
		return getSpecFeatures( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specFeatures</code> attribute. 
	 * @param value the specFeatures - Technical Specification Constructions List
	 */
	public void setSpecFeatures(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECFEATURES,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specFeatures</code> attribute. 
	 * @param value the specFeatures - Technical Specification Constructions List
	 */
	public void setSpecFeatures(final String value)
	{
		setSpecFeatures( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specLegend</code> attribute.
	 * @return the specLegend - Technical Specification SAMPLE PRINT LEGEND
	 */
	public String getSpecLegend(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECLEGEND);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specLegend</code> attribute.
	 * @return the specLegend - Technical Specification SAMPLE PRINT LEGEND
	 */
	public String getSpecLegend()
	{
		return getSpecLegend( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specLegend</code> attribute. 
	 * @param value the specLegend - Technical Specification SAMPLE PRINT LEGEND
	 */
	public void setSpecLegend(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECLEGEND,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specLegend</code> attribute. 
	 * @param value the specLegend - Technical Specification SAMPLE PRINT LEGEND
	 */
	public void setSpecLegend(final String value)
	{
		setSpecLegend( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specNumber</code> attribute.
	 * @return the specNumber - Technical Specification Number
	 */
	public String getSpecNumber(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECNUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specNumber</code> attribute.
	 * @return the specNumber - Technical Specification Number
	 */
	public String getSpecNumber()
	{
		return getSpecNumber( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specNumber</code> attribute. 
	 * @param value the specNumber - Technical Specification Number
	 */
	public void setSpecNumber(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECNUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specNumber</code> attribute. 
	 * @param value the specNumber - Technical Specification Number
	 */
	public void setSpecNumber(final String value)
	{
		setSpecNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specSpecifications</code> attribute.
	 * @return the specSpecifications - Technical Specification specifications
	 */
	public String getSpecSpecifications(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECSPECIFICATIONS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specSpecifications</code> attribute.
	 * @return the specSpecifications - Technical Specification specifications
	 */
	public String getSpecSpecifications()
	{
		return getSpecSpecifications( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specSpecifications</code> attribute. 
	 * @param value the specSpecifications - Technical Specification specifications
	 */
	public void setSpecSpecifications(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECSPECIFICATIONS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specSpecifications</code> attribute. 
	 * @param value the specSpecifications - Technical Specification specifications
	 */
	public void setSpecSpecifications(final String value)
	{
		setSpecSpecifications( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specTitle</code> attribute.
	 * @return the specTitle - Technical Specification Title
	 */
	public String getSpecTitle(final SessionContext ctx)
	{
		return (String)getProperty( ctx, SPECTITLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>TechSpec.specTitle</code> attribute.
	 * @return the specTitle - Technical Specification Title
	 */
	public String getSpecTitle()
	{
		return getSpecTitle( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specTitle</code> attribute. 
	 * @param value the specTitle - Technical Specification Title
	 */
	public void setSpecTitle(final SessionContext ctx, final String value)
	{
		setProperty(ctx, SPECTITLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>TechSpec.specTitle</code> attribute. 
	 * @param value the specTitle - Technical Specification Title
	 */
	public void setSpecTitle(final String value)
	{
		setSpecTitle( getSession().getSessionContext(), value );
	}
	
}
